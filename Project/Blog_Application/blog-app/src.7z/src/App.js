import logo from './logo.svg';
import { Button } from 'reactstrap';
import Base from './Components/Base';
import SingUp from './Pages/SignUp';
import 'react-toastify/dist/ReactToastify.css';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './Pages/Home';
import LogIn from './Pages/Login';
import About from './Pages/About';
import SignUp from './Pages/SignUp';
import Service from './Pages/Services';
import { ToastContainer, toast } from 'react-toastify';
import PrivateRoute from './Components/PrivateRoute';
import UserDashboard from './Pages/user-routes/UserDashboard';
import ProfileInfo from './Pages/user-routes/ProfileInfo';

function App() {
  return (

    <BrowserRouter>

      <ToastContainer position='bottom-center' />
      <Routes>
        <Route path='/home' element={<Home />}></Route>
        <Route path='/login' element={<LogIn />}></Route>
        <Route path='/signUp' element={<SignUp />}></Route>
        <Route path='/about' element={<About />}></Route>
        <Route path='/service' element={<Service />}></Route>

        <Route path='/user' element={<PrivateRoute />}>
          <Route path='UserDashboard' element={<UserDashboard />}></Route>
          <Route path='profileinfo' element={<ProfileInfo />}></Route>
        </Route>


        <Route path='/' element={<Home />}></Route>
      </Routes>

    </BrowserRouter>
  );
}

export default App;
