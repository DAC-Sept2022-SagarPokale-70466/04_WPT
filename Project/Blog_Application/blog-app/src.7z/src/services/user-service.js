import { MYAXIOIS } from "./helper";

export const singup = (user) => {

    return MYAXIOIS.post('/api/v1/auth/register', user).then((response) => response.data)
}

export const loginUser  = (loginDetails) =>{
    // debugger
    return MYAXIOIS.post('/api/v1/auth/login',loginDetails).then((response) => response.data)
}