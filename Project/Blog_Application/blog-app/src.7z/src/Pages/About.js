import Base from "../Components/Base";

const About = ()=>{
    return (<Base> 
    
    <h1>This is About Page</h1>
    <p>We are building App JS</p>


    </Base>)
}

export default About;