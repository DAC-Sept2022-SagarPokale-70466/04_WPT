import Base from "../Components/Base";

const Service = () =>{
return(
    <Base>
    
    <h1>This is service Page</h1>
    
    </Base>
);

}
export default Service;
