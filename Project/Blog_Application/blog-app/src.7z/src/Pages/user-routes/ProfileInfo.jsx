import React from 'react'

function ProfileInfo() {
  return (
    <div>ProfileInfo</div>
  )
}

export default ProfileInfo