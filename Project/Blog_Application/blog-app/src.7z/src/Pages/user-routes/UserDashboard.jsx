//rfce

import React from 'react'

const UserDashboard = ()=> {
  return (
    <div>Welcome to User Dashboard</div>
  )
}

export default UserDashboard