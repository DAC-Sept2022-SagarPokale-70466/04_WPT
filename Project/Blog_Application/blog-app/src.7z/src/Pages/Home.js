import Base from "../Components/Base";

const Home = () => {
    return (<div>

        <Base>
            <h1>This is Welcome to Home Page</h1>
            {/* This is Base Child */}
        </Base>

    </div>);
}

export default Home;
